Xie Dynasty Notes - Windows x64 Application
===========================================

INSTALLATION INSTRUCTIONS
-------------------------

1. Extract all files from this zip to a folder on your computer
   (Keep the .exe and .dll files in the same folder!)

2. Double-click "xie-dynasty-notes-windows-x64.exe" to run the application

3. If you see an error about WebView2 Runtime missing:
   - Download and install Microsoft Edge WebView2 Runtime from:
     https://developer.microsoft.com/en-us/microsoft-edge/webview2/
   - Choose "Evergreen Standalone Installer" for x64
   - After installation, run the .exe again

IMPORTANT NOTES
---------------

* KEEP FILES TOGETHER: The .exe and WebView2Loader.dll MUST be in the same folder
  Do not move or delete the .dll file!

* BACKEND REQUIRED: This app currently connects to http://localhost:8000
  You need to run the backend server locally for the app to work:
  
  1. Navigate to the backend folder: apps/server
  2. Install dependencies: poetry install
  3. Run the server: poetry run uvicorn app.main:app --reload
  4. Then run this desktop app

* FIRST RUN: Windows may show a security warning because the app is not signed
  Click "More info" then "Run anyway" to proceed

SYSTEM REQUIREMENTS
-------------------

* Windows 10 (version 1809 or later) or Windows 11
* 64-bit (x64) processor (Intel or AMD)
* 4 GB RAM minimum, 8 GB recommended
* 100 MB free disk space
* Internet connection (for backend sync)

TROUBLESHOOTING
---------------

Problem: "WebView2Loader.dll not found"
Solution: Make sure the .dll file is in the same folder as the .exe

Problem: App shows blank white screen
Solution: Install WebView2 Runtime from the link above

Problem: "Connection failed" or "Cannot connect to server"
Solution: Make sure the backend server is running on localhost:8000

Problem: Windows Defender blocks the app
Solution: This is a false positive. Click "More info" → "Run anyway"
         Or add an exception in Windows Security settings

WHAT'S INCLUDED
---------------

* xie-dynasty-notes-windows-x64.exe (19 MB) - Main application
* WebView2Loader.dll (162 KB) - Required WebView2 component
* README.txt - This file

FEATURES
--------

* Rich text editing with formatting (bold, italic, headings, lists, tables, code blocks)
* Real-time collaborative editing with other users
* Offline-first with automatic sync when online
* Hierarchical organization: Workspaces → Notebooks → Sections → Pages
* Modern, polished user interface

GETTING STARTED
---------------

1. Start the backend server (see BACKEND REQUIRED section above)
2. Run the desktop app
3. Register a new account or login
4. Create your first workspace and start taking notes!

SUPPORT
-------

For issues or questions:
* GitHub Repository: https://github.com/genealogyxie/xie-dynasty-notes
* Pull Request: https://github.com/genealogyxie/xie-dynasty-notes/pull/1

VERSION INFORMATION
-------------------

Version: 0.1.0
Build Date: November 20, 2025
Platform: Windows x64 (Intel/AMD)
Built with: Tauri 2.9.3, Rust 1.83.0

LEGAL
-----

This software is provided as-is without warranty of any kind.
