package com.xiedynasty.notes;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
